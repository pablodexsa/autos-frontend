import React, { useEffect, useMemo, useState } from "react";
import {
  Box,
  Paper,
  Typography,
  TextField,
  MenuItem,
  Button,
  Dialog,
  DialogTitle,
  DialogContent,
  Snackbar,
  Alert,
  FormControlLabel,
  Checkbox,
} from "@mui/material";
import api from "../api/api";
import LoadingActionButton from "../components/LoadingActionButton";

type Vehicle = {
  id: number;
  brand: string;
  model: string;
  versionName?: string;
  plate?: string;
  price: number;
  isMotoPlan?: boolean;
};

type AlertSeverity = "success" | "info" | "warning" | "error";
type AlertState = { open: boolean; message: string; severity: AlertSeverity };

type MotoPlanOption = {
  code: string;
  name: string;
  installments: number;
  downPayment?: number;
  totalInstallments?: number;
  firstInstallmentsCount?: number;
  firstInstallmentAmount?: number;
  remainingInstallmentAmount?: number;
};

const Sales: React.FC = () => {
  const [vehicles, setVehicles] = useState<Vehicle[]>([]);
  const [selectedVehicle, setSelectedVehicle] = useState<Vehicle | null>(null);
  const [savingSale, setSavingSale] = useState(false);
  const [previewOpen, setPreviewOpen] = useState(false);

  const [alert, setAlert] = useState<AlertState>({
    open: false,
    message: "",
    severity: "success",
  });

  const [errors, setErrors] = useState({
    tradeIn: "",
    prendario: "",
    financiacion: "",
  });

  const [loanRates, setLoanRates] = useState<Record<string, number>>({});
  const [maxPersonalFinancing, setMaxPersonalFinancing] =
    useState<number>(3500000);
  const [motoPlans, setMotoPlans] = useState<MotoPlanOption[]>([]);

  const nextTwoMonths = useMemo(() => {
    const now = new Date();
    const m1 = new Date(now.getFullYear(), now.getMonth() + 1, 1);
    const m2 = new Date(now.getFullYear(), now.getMonth() + 2, 1);
    const fmt = (d: Date) =>
      `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`;
    return [fmt(m1), fmt(m2)];
  }, []);

  const [form, setForm] = useState({
    dni: "",
    clientName: "",
    vehicleId: "",
    price: "",
    paymentType: "",
    selectedMotoPlan: "",
    installments: "",
    hasTradeIn: false,
    tradeInValue: "",
    tradeInPlate: "",
    downPayment: "",
    montoPrendario: "",
    montoPersonal: "",
    montoFinanciacion: "",
    balance: "",
    finalPrice: "",
    installmentValue: "",
    paymentDay: 5,
    initialPaymentMonth: "",
    kairosFinancedAmount: "",
    kairosWeeklyInstallments: "",
    saleDate: new Date().toISOString().slice(0, 10),
  });

  const formatPesos = (valor: any) => {
    if (valor === "" || valor === null || valor === undefined) return "-";
    const n = Number(valor) || 0;
    return `$ ${n.toLocaleString("es-AR", {
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    })}`;
  };

  useEffect(() => {
    api
      .get("/loan-rates")
      .then((res) => {
        const map: Record<string, number> = {};
        (res.data || []).forEach((r: any) => {
          const key = `${r.type}_${r.months}`;
          map[key] = Number(r.rate);
        });
        setLoanRates(map);
      })
      .catch((err) => {
        console.error("Error cargando tasas de financiación:", err);
      });
  }, []);

  useEffect(() => {
    api
      .get("/settings/financing/personal-max")
      .then((res) => {
        const v = Number(res.data?.maxPersonalAmount);
        if (Number.isFinite(v) && v > 0) {
          setMaxPersonalFinancing(v);
        }
      })
      .catch((err) => {
        console.error(
          "Error cargando máximo de financiación personal:",
          err
        );
      });
  }, []);

  useEffect(() => {
    api
      .get("/settings/moto-plans")
      .then((res) => {
        const data = Array.isArray(res.data) ? res.data : [];
        setMotoPlans(data);
      })
      .catch((err) => {
        console.error("Error cargando planes de motos:", err);
        setMotoPlans([]);
      });
  }, []);

  const mapMonthsToBracket = (months: number): number => {
    if (!months || months <= 0) return 0;
    if (months <= 12) return 12;
    if (months <= 24) return 24;
    if (months <= 36) return 36;
    if (months <= 48) return 48;
    return 0;
  };

  const getRate = (
    type: "prendario" | "personal" | "financiacion",
    months: number
  ): number => {
    const bracket = mapMonthsToBracket(months);
    if (!bracket) return 0;
    return loanRates[`${type}_${bracket}`] ?? 0;
  };

  const loadVehicles = async (dni?: string) => {
    try {
      const res = await api.get(
        `/sales/eligible-vehicles${dni ? `?dni=${encodeURIComponent(dni)}` : ""}`
      );
      const data: Vehicle[] = Array.isArray(res.data)
        ? res.data
        : res.data?.items ?? [];
      setVehicles(data ?? []);
    } catch (error) {
      console.error("Error cargando vehículos:", error);
      setVehicles([]);
    }
  };

  useEffect(() => {
    loadVehicles();
    setForm((prev) => ({ ...prev, initialPaymentMonth: nextTwoMonths[0] }));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [nextTwoMonths]);

  const handleDniChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const dniValue = e.target.value;
    setForm((prev) => ({ ...prev, dni: dniValue }));

    if (dniValue.trim().length === 8) {
      try {
        const res = await api.get(
          `/clients/search/by-dni?dni=${encodeURIComponent(dniValue.trim())}`
        );
        if (res.data?.length > 0) {
          const c = res.data[0];
          setForm((prev) => ({
            ...prev,
            clientName: `${c.firstName} ${c.lastName}`,
          }));
          await loadVehicles(dniValue.trim());
        } else {
          setForm((prev) => ({ ...prev, clientName: "" }));
        }
      } catch (err) {
        console.error("Error buscando cliente:", err);
        setForm((prev) => ({ ...prev, clientName: "" }));
      }
    } else {
      setForm((prev) => ({ ...prev, clientName: "" }));
    }
  };

  const handleVehicleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const vehicleId = e.target.value;
    const vehicle =
      vehicles.find((v) => String(v.id) === String(vehicleId)) || null;
    setSelectedVehicle(vehicle);

    if (vehicle) {
      const priceStr = String(Number(vehicle.price || 0).toFixed(2));
      setForm((prev) => ({
        ...prev,
        vehicleId,
        price: priceStr,
        paymentType: "",
        selectedMotoPlan: "",
        balance: priceStr,
        finalPrice: priceStr,
        downPayment: "",
        tradeInValue: "",
        tradeInPlate: "",
        montoPrendario: "",
        montoPersonal: "",
        montoFinanciacion: "",
        installments: "",
        installmentValue: "",
            kairosFinancedAmount: "",
        kairosWeeklyInstallments: "",
        saleDate: new Date().toISOString().slice(0, 10),
      }));
    } else {
      setForm((prev) => ({
        ...prev,
        vehicleId,
        price: "",
        paymentType: "",
        selectedMotoPlan: "",
        balance: "",
        finalPrice: "",
        downPayment: "",
        tradeInValue: "",
        tradeInPlate: "",
        montoPrendario: "",
        montoPersonal: "",
        montoFinanciacion: "",
        installments: "",
        installmentValue: "",
            kairosFinancedAmount: "",
        kairosWeeklyInstallments: "",
        saleDate: new Date().toISOString().slice(0, 10),
      }));
    }
  };

  useEffect(() => {
    if (!form.hasTradeIn) {
      setForm((prev) => ({
        ...prev,
        tradeInValue: "",
        tradeInPlate: "",
        balance: selectedVehicle
          ? String(Number(selectedVehicle.price || 0).toFixed(2))
          : "",
      }));
    }
  }, [form.hasTradeIn, selectedVehicle]);

  useEffect(() => {
    if (!selectedVehicle) return;

    const price = Number(selectedVehicle.price) || 0;
    const tradeIn = form.hasTradeIn ? Number(form.tradeInValue) || 0 : 0;
    const montoFinanciacionNum = Number(form.montoFinanciacion) || 0;

    const newBalance = Math.max(price - tradeIn, 0);
    const newBalanceStr = newBalance.toFixed(2);
    if (form.balance !== newBalanceStr) {
      setForm((prev) => ({ ...prev, balance: newBalanceStr }));
    }

    const newErrors = { tradeIn: "", prendario: "", financiacion: "" };

    if (form.hasTradeIn && tradeIn > price) {
      newErrors.tradeIn =
        "El valor de la permuta no puede superar el precio del vehículo.";
    }

    if (montoFinanciacionNum > maxPersonalFinancing) {
      newErrors.financiacion = `El monto máximo de financiación personal es $${maxPersonalFinancing.toLocaleString(
        "es-AR"
      )}.`;
    }

    if (
      newErrors.tradeIn !== errors.tradeIn ||
      newErrors.prendario !== errors.prendario ||
      newErrors.financiacion !== errors.financiacion
    ) {
      setErrors(newErrors);
      if (newErrors.tradeIn || newErrors.prendario || newErrors.financiacion) {
        const msg =
          newErrors.tradeIn || newErrors.prendario || newErrors.financiacion;
        setAlert({ open: true, message: msg, severity: "warning" });
      }
    }

    if (form.paymentType === "contado") {
      if (
        form.downPayment ||
        form.montoPrendario ||
        form.montoPersonal ||
        form.montoFinanciacion ||
        form.installments
      ) {
        setForm((prev) => ({
          ...prev,
          downPayment: "",
          montoPrendario: "",
          montoPersonal: "",
          montoFinanciacion: "",
          installments: "",
          installmentValue: "",
        }));
      }
      return;
    }

    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [
    selectedVehicle,
    form.hasTradeIn,
    form.tradeInValue,
    form.downPayment,
    form.montoPrendario,
    form.montoFinanciacion,
    form.paymentType,
    maxPersonalFinancing,
  ]);

  useEffect(() => {
    if (form.paymentType !== "plan_motos_0km") return;

    if (!form.selectedMotoPlan) {
      setForm((prev) => ({
        ...prev,
        downPayment: "",
        installments: "",
        installmentValue: "",
        finalPrice: selectedVehicle
          ? String(Number(selectedVehicle.price || 0).toFixed(2))
          : "",
      }));
      return;
    }

    const selected = motoPlans.find((p) => p.code === form.selectedMotoPlan);
    if (!selected) return;

    const downPayment = Number(selected.downPayment ?? 0);
    const totalInstallments = Number(
      selected.totalInstallments ?? selected.installments ?? 0
    );
    const firstInstallmentsCount = Number(selected.firstInstallmentsCount ?? 0);
    const firstInstallmentAmount = Number(selected.firstInstallmentAmount ?? 0);
    const remainingInstallmentAmount = Number(
      selected.remainingInstallmentAmount ?? 0
    );

    const remainingInstallments =
      totalInstallments - firstInstallmentsCount;

    const totalPlan =
      downPayment +
      firstInstallmentsCount * firstInstallmentAmount +
      remainingInstallments * remainingInstallmentAmount;

    const installmentValue =
      firstInstallmentsCount === 0 ||
      firstInstallmentAmount === remainingInstallmentAmount
        ? String(Number(remainingInstallmentAmount).toFixed(2))
        : "";

    setForm((prev) => ({
      ...prev,
      downPayment: String(Number(downPayment).toFixed(2)),
      installments: String(totalInstallments),
      installmentValue,
      finalPrice: String(Number(totalPlan).toFixed(2)),
      montoPrendario: "",
      montoPersonal: "",
      montoFinanciacion: "",
    }));
  }, [form.paymentType, form.selectedMotoPlan, selectedVehicle, motoPlans]);

  useEffect(() => {
    if (!selectedVehicle) return;
    if (form.paymentType === "plan_motos_0km") return;

    const price = Number(selectedVehicle.price) || 0;
    const tradeIn = form.hasTradeIn ? Number(form.tradeInValue) || 0 : 0;
    const balance = Math.max(price - tradeIn, 0);
    const anticipo = Math.max(0, Number(form.downPayment) || 0);
    const nCuotas = Number(form.installments) || 0;

    const prendario = Number(form.montoPrendario) || 0;
    const personal = Number(form.montoPersonal) || 0;
    const financiacion = Number(form.montoFinanciacion) || 0;

    const restante = Math.max(
      balance - anticipo - prendario - personal - financiacion,
      0
    );
    const finalPrice =
      anticipo + prendario + personal + financiacion + restante;

    let installmentValue = 0;
    if (nCuotas > 0 && prendario + personal + financiacion > 0) {
      installmentValue = (prendario + personal + financiacion) / nCuotas;
    }

    const next = {
      finalPrice: finalPrice.toFixed(2),
      installmentValue: installmentValue ? installmentValue.toFixed(2) : "",
      balance: balance.toFixed(2),
    };

    if (
      form.finalPrice !== next.finalPrice ||
      form.installmentValue !== next.installmentValue ||
      form.balance !== next.balance
    ) {
      setForm((prev) => ({
        ...prev,
        ...next,
      }));
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [
    selectedVehicle,
    form.paymentType,
    form.installments,
    form.downPayment,
    form.montoPrendario,
    form.montoPersonal,
    form.montoFinanciacion,
    form.tradeInValue,
  ]);

  const hasErrors = Object.values(errors).some((msg) => !!msg);

  const isMotoPlanVehicle = !!selectedVehicle?.isMotoPlan;
  const isMotoPlanPayment = form.paymentType === "plan_motos_0km";
  const isKairosPayment = form.paymentType === "kairos_financing";

  const kairosFinancedAmount = Number(form.kairosFinancedAmount) || 0;
  const kairosWeeklyInstallments = Number(form.kairosWeeklyInstallments) || 0;
  const kairosInterestAmount = Math.round(
    kairosFinancedAmount * 0.25 * (kairosWeeklyInstallments / 4)
  );
  const kairosTotalToRepay = kairosFinancedAmount + kairosInterestAmount;
  const kairosInstallmentValue =
    kairosWeeklyInstallments > 0
      ? kairosTotalToRepay / kairosWeeklyInstallments
      : 0;
  const kairosDataMissing =
    isKairosPayment &&
    (kairosFinancedAmount <= 0 ||
      ![6, 8, 10, 12, 15, 18, 20, 22, 24, 26, 28, 30, 32, 34, 36].includes(
        kairosWeeklyInstallments
      ) ||
      !form.saleDate);

  const kairosFirstDueDate = useMemo(() => {
    if (!form.saleDate) return "";
    const [year, month, day] = form.saleDate.split("-").map(Number);
    const date = new Date(year, month - 1, day, 12, 0, 0);
    date.setDate(date.getDate() + 7);
    return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}-${String(
      date.getDate()
    ).padStart(2, "0")}`;
  }, [form.saleDate]);

  const requiresInstallments = form.paymentType === "anticipo_financiacion";
  const missingInstallments = requiresInstallments && !form.installments;

  const vehiclePrice =
    selectedVehicle && selectedVehicle.price
      ? Number(selectedVehicle.price) || 0
      : 0;

  const totalComposition =
    (Number(form.downPayment) || 0) +
    (form.hasTradeIn ? Number(form.tradeInValue) || 0 : 0) +
    (Number(form.montoPrendario) || 0) +
    (isKairosPayment
      ? kairosFinancedAmount
      : (Number(form.montoPersonal) || 0) +
        (Number(form.montoFinanciacion) || 0));

  const someAmountEntered =
    (Number(form.downPayment) || 0) ||
    (form.hasTradeIn ? Number(form.tradeInValue) || 0 : 0) ||
    (Number(form.montoPrendario) || 0) ||
    (isKairosPayment
      ? kairosFinancedAmount
      : (Number(form.montoPersonal) || 0) +
        (Number(form.montoFinanciacion) || 0));

  const compositionDiff =
    selectedVehicle && someAmountEntered
      ? Math.abs(totalComposition - vehiclePrice)
      : 0;

  const compositionMismatch =
    (form.paymentType === "anticipo_financiacion" || isKairosPayment) &&
    !!selectedVehicle &&
    compositionDiff > 1;

  const nCuotas = Number(form.installments) || 0;
  const netoPrendario = Number(form.montoPrendario) || 0;
  const netoPersonal = Number(form.montoPersonal) || 0;
  const netoFinanciacion = Number(form.montoFinanciacion) || 0;

  const tasaPrendario = getRate("prendario", nCuotas);
  const tasaPersonal = getRate("personal", nCuotas);
  const tasaFinanciacion = getRate("financiacion", nCuotas);

  const prendarioConInteres =
    netoPrendario > 0 ? netoPrendario * (1 + tasaPrendario / 100) : 0;
  const personalConInteres =
    netoPersonal > 0 ? netoPersonal * (1 + tasaPersonal / 100) : 0;
  const financiacionConInteres =
    netoFinanciacion > 0 ? netoFinanciacion * (1 + tasaFinanciacion / 100) : 0;

  const totalPrestamosConInteres =
    prendarioConInteres + personalConInteres + financiacionConInteres;

  const valorCuotaTotalConInteres =
    nCuotas > 0 && totalPrestamosConInteres > 0
      ? totalPrestamosConInteres / nCuotas
      : 0;

  const selectedMotoPlanConfig = useMemo(() => {
    if (!isMotoPlanPayment || !form.selectedMotoPlan) return null;

    const selected = motoPlans.find((p) => p.code === form.selectedMotoPlan);
    if (!selected) return null;

    return {
      code: selected.code,
      name: selected.name,
      downPayment: Number(selected.downPayment ?? 0),
      totalInstallments: Number(
        selected.totalInstallments ?? selected.installments ?? 0
      ),
      firstInstallmentsCount: Number(selected.firstInstallmentsCount ?? 0),
      firstInstallmentAmount: Number(selected.firstInstallmentAmount ?? 0),
      remainingInstallmentAmount: Number(
        selected.remainingInstallmentAmount ?? 0
      ),
    };
  }, [isMotoPlanPayment, form.selectedMotoPlan, motoPlans]);

  const motoPlanRemainingInstallments = selectedMotoPlanConfig
    ? selectedMotoPlanConfig.totalInstallments -
      selectedMotoPlanConfig.firstInstallmentsCount
    : 0;

  const motoPlanTotal = selectedMotoPlanConfig
    ? selectedMotoPlanConfig.downPayment +
      selectedMotoPlanConfig.firstInstallmentsCount *
        selectedMotoPlanConfig.firstInstallmentAmount +
      motoPlanRemainingInstallments *
        selectedMotoPlanConfig.remainingInstallmentAmount
    : 0;

  const labelPayment = (p: string) => {
    switch (p) {
      case "contado":
        return "Contado";
      case "anticipo_financiacion":
        return "Anticipo + Financiación";
      case "plan_motos_0km":
        return "Plan Motos 0km";
      case "kairos_financing":
        return "Financiación Kairos";
      default:
        return "-";
    }
  };

  const handlePaymentTypeChange = (
    value:
      | ""
      | "contado"
      | "anticipo_financiacion"
      | "plan_motos_0km"
      | "kairos_financing"
  ) => {
    setErrors({ tradeIn: "", prendario: "", financiacion: "" });
    setForm((prev) => ({
      ...prev,
      paymentType: value,
      kairosFinancedAmount:
        value === "kairos_financing" ? prev.kairosFinancedAmount : "",
      kairosWeeklyInstallments:
        value === "kairos_financing" ? prev.kairosWeeklyInstallments : "",
      saleDate:
        value === "kairos_financing"
          ? prev.saleDate || new Date().toISOString().slice(0, 10)
          : prev.saleDate,
      ...(value === "contado"
        ? {
            selectedMotoPlan: "",
            downPayment: "",
            montoPrendario: "",
            montoPersonal: "",
            montoFinanciacion: "",
            installments: "",
            installmentValue: "",
          }
        : {}),
      ...(value === "anticipo_financiacion"
        ? {
            selectedMotoPlan: "",
          }
        : {}),
      ...(value === "kairos_financing"
        ? {
            selectedMotoPlan: "",
            montoPersonal: "",
            montoFinanciacion: "",
            installments: "",
            installmentValue: "",
          }
        : {}),
      ...(value === "plan_motos_0km"
        ? {
            selectedMotoPlan: "",
            downPayment: "",
            montoPrendario: "",
            montoPersonal: "",
            montoFinanciacion: "",
            installments: "",
            installmentValue: "",
          }
        : {}),
    }));
  };

const handleSaveSale = async () => {
  if (savingSale) return;

  try {
    setSavingSale(true);

    if (!selectedVehicle) {
      setAlert({
        open: true,
        message: "Debe seleccionar un vehículo.",
        severity: "warning",
      });
      return;
    }

    if (!form.paymentType) {
      setAlert({
        open: true,
        message: "Debe seleccionar la forma de pago.",
        severity: "warning",
      });
      return;
    }

    if (form.paymentType === "kairos_financing") {
      if (kairosFinancedAmount <= 0) {
        setAlert({
          open: true,
          message: "Debe ingresar un monto Kairos mayor a cero.",
          severity: "warning",
        });
        return;
      }

      const allowedKairosInstallments = [
        6, 8, 10, 12, 15, 18, 20, 22, 24, 26, 28, 30, 32, 34, 36,
      ];
      if (!allowedKairosInstallments.includes(kairosWeeklyInstallments)) {
        setAlert({
          open: true,
          message: "Seleccione una cantidad válida de cuotas semanales Kairos.",
          severity: "warning",
        });
        return;
      }

      if (!form.saleDate) {
        setAlert({
          open: true,
          message: "Debe indicar la fecha de venta.",
          severity: "warning",
        });
        return;
      }
    }

    if (form.paymentType === "anticipo_financiacion" && !form.installments) {
      setAlert({
        open: true,
        message: "Debe seleccionar la cantidad de cuotas.",
        severity: "warning",
      });
      return;
    }

    if (form.paymentType === "plan_motos_0km" && !form.selectedMotoPlan) {
      setAlert({
        open: true,
        message: "Debe seleccionar un plan.",
        severity: "warning",
      });
      return;
    }

    if (form.paymentType === "kairos_financing") {
      const vehiclePriceLocal = Number(selectedVehicle.price) || 0;
      const totalCompositionLocal =
        (Number(form.downPayment) || 0) +
        (form.hasTradeIn ? Number(form.tradeInValue) || 0 : 0) +
        (Number(form.montoPrendario) || 0) +
        kairosFinancedAmount;

      if (Math.abs(totalCompositionLocal - vehiclePriceLocal) > 1) {
        setAlert({
          open: true,
          message: `Los montos no suman el valor del auto. La suma cargada es ${formatPesos(
            totalCompositionLocal
          )} y el vehículo vale ${formatPesos(vehiclePriceLocal)}.`,
          severity: "warning",
        });
        return;
      }
    }

    if (form.paymentType === "anticipo_financiacion") {
      const vehiclePriceLocal = Number(selectedVehicle.price) || 0;
      const totalCompositionLocal =
        (Number(form.downPayment) || 0) +
        (form.hasTradeIn ? Number(form.tradeInValue) || 0 : 0) +
        (Number(form.montoPrendario) || 0) +
        (Number(form.montoPersonal) || 0) +
        (Number(form.montoFinanciacion) || 0);

      const diffLocal = Math.abs(totalCompositionLocal - vehiclePriceLocal);

      if (diffLocal > 1) {
        setAlert({
          open: true,
          message: `La suma de anticipo, permuta y financiaciones ($${totalCompositionLocal.toLocaleString(
            "es-AR"
          )}) debe coincidir con el precio del vehículo ($${vehiclePriceLocal.toLocaleString(
            "es-AR"
          )}). Revise los importes.`,
          severity: "warning",
        });
        return;
      }
    }

    const payload = {
      clientDni: form.dni.trim(),
      clientName: form.clientName.trim(),
      vehicleId: Number(selectedVehicle.id),
      basePrice: Number(selectedVehicle.price),
      paymentType: form.paymentType,
      motoPlanCode: form.selectedMotoPlan || null,
      hasTradeIn: !!form.hasTradeIn,
      tradeInValue: Number(form.tradeInValue) || 0,
      tradeInPlate: form.tradeInPlate.trim() || null,
      downPayment: Number(form.downPayment) || 0,
      prendarioAmount: Number(form.montoPrendario) || 0,
      personalAmount: Number(form.montoPersonal) || 0,
      inHouseAmount: Number(form.montoFinanciacion) || 0,
      finalPrice: Number(form.finalPrice) || 0,
      balance: Number(form.balance) || 0,
      paymentDay: Number(form.paymentDay),
      initialPaymentMonth: form.initialPaymentMonth,
      prendarioInstallments: Number(form.installments) || 0,
      personalInstallments: Number(form.installments) || 0,
      inHouseInstallments: Number(form.installments) || 0,
      prendarioMonthlyRate: 0,
      personalMonthlyRate: 0,
      inHouseMonthlyRate: 0,
      kairosFinancedAmount:
        form.paymentType === "kairos_financing"
          ? kairosFinancedAmount
          : undefined,
      kairosWeeklyInstallments:
        form.paymentType === "kairos_financing"
          ? kairosWeeklyInstallments
          : undefined,
      saleDate:
        form.paymentType === "kairos_financing" ? form.saleDate : undefined,
    };

    const res = await api.post("/sales", payload, {
      headers: { "Content-Type": "application/json" },
    });
    const newSale = res.data;

    const pdfUrl = `${import.meta.env.VITE_API_URL}/sales/${newSale.id}/pdf`;
    const response = await fetch(pdfUrl);
    const blob = await response.blob();
    const url = window.URL.createObjectURL(blob);
    const fileName = `Comprobante-Venta-${(form.clientName || "cliente")
      .replace(/\s+/g, "_")
      .replace(/[^\w\-]/g, "")}-${newSale.id}.pdf`;

    const link = document.createElement("a");
    link.href = url;
    link.download = fileName;
    link.click();
    window.open(url, "_blank");
    window.URL.revokeObjectURL(url);

    setAlert({
      open: true,
      message: "Venta registrada y comprobante descargado correctamente.",
      severity: "success",
    });
    setPreviewOpen(false);
  } catch (err: any) {
    console.log("❌ Error guardando venta FULL:", err);
    console.log("❌ status:", err?.response?.status);
    console.log("❌ data:", err?.response?.data);
    console.log("❌ message:", err?.response?.data?.message);
    alert(
      `Error guardando venta: ${err?.response?.status} - ${
        err?.response?.data?.message || "sin mensaje"
      }`
    );
  } finally {
    setSavingSale(false);
  }
};

  return (
    <Box>
      <Typography variant="h5" sx={{ mb: 3, fontWeight: 600 }}>
        Registrar Venta
      </Typography>

      <Paper
        sx={{
          p: 3,
          backgroundColor: "#1e1e2f",
          borderRadius: 2,
          boxShadow: "0px 4px 12px rgba(0,0,0,0.4)",
        }}
      >
        <Box display="grid" gridTemplateColumns="repeat(2, 1fr)" gap={2}>
          <TextField
            label="DNI del Cliente"
            value={form.dni}
            onChange={handleDniChange}
            fullWidth
            sx={{ input: { color: "#fff" }, label: { color: "#ccc" } }}
          />
          <TextField
            label="Nombre del Cliente"
            value={form.clientName}
            InputProps={{ readOnly: true }}
            fullWidth
            sx={{ input: { color: "#fff" }, label: { color: "#ccc" } }}
          />

          <TextField
            select
            label="Vehículo"
            value={form.vehicleId}
            onChange={handleVehicleChange}
            fullWidth
            sx={{ input: { color: "#fff" }, label: { color: "#ccc" } }}
          >
            {vehicles.map((v) => (
              <MenuItem key={v.id} value={String(v.id)}>
                {v.brand} {v.model} {v.versionName || ""} (
                {v.plate || "sin patente"})
              </MenuItem>
            ))}
          </TextField>

          <TextField
            label="Precio Base"
            value={form.price}
            InputProps={{ readOnly: true }}
            fullWidth
            sx={{ input: { color: "#fff" }, label: { color: "#ccc" } }}
          />

          <FormControlLabel
            control={
              <Checkbox
                checked={form.hasTradeIn}
                onChange={(e) =>
                  setForm((prev) => ({ ...prev, hasTradeIn: e.target.checked }))
                }
                sx={{ color: "#ccc" }}
              />
            }
            label="¿Tiene Permuta?"
          />

          {form.hasTradeIn && (
            <>
              <TextField
                label="Valor de la Permuta"
                type="number"
                value={form.tradeInValue}
                onChange={(e) =>
                  setForm((prev) => ({
                    ...prev,
                    tradeInValue: e.target.value,
                  }))
                }
                fullWidth
                error={!!errors.tradeIn}
                helperText={errors.tradeIn}
                sx={{ input: { color: "#fff" }, label: { color: "#ccc" } }}
              />
              <TextField
                label="Patente de la Permuta"
                value={form.tradeInPlate}
                onChange={(e) =>
                  setForm((prev) => ({
                    ...prev,
                    tradeInPlate: e.target.value.toUpperCase(),
                  }))
                }
                fullWidth
                sx={{ input: { color: "#fff" }, label: { color: "#ccc" } }}
              />
              <TextField
                label="Saldo (Vehículo - Permuta)"
                value={form.balance}
                InputProps={{ readOnly: true }}
                fullWidth
                sx={{ input: { color: "#fff" }, label: { color: "#ccc" } }}
              />
            </>
          )}

          <TextField
            select
            label="Forma de Pago"
            value={form.paymentType}
            onChange={(e) =>
              handlePaymentTypeChange(
                e.target.value as
                  | ""
                  | "contado"
                  | "anticipo_financiacion"
                  | "plan_motos_0km"
                  | "kairos_financing"
              )
            }
            fullWidth
            sx={{ input: { color: "#fff" }, label: { color: "#ccc" } }}
          >
            <MenuItem value="contado">Contado</MenuItem>
            <MenuItem value="anticipo_financiacion">
              Anticipo + Financiación
            </MenuItem>
            <MenuItem value="kairos_financing">
              Anticipo + Financiación Kairos
            </MenuItem>
            {isMotoPlanVehicle && (
              <MenuItem value="plan_motos_0km">Plan Motos 0km</MenuItem>
            )}
          </TextField>

          {isKairosPayment && (
            <>
              <TextField
                label="Anticipo"
                type="number"
                value={form.downPayment}
                onChange={(e) =>
                  setForm((prev) => ({ ...prev, downPayment: e.target.value }))
                }
                inputProps={{ min: 0, step: 1 }}
                fullWidth
                sx={{ input: { color: "#fff" }, label: { color: "#ccc" } }}
              />

              <TextField
                label="Monto Préstamo Prendario (neto)"
                type="number"
                value={form.montoPrendario}
                onChange={(e) =>
                  setForm((prev) => ({ ...prev, montoPrendario: e.target.value }))
                }
                inputProps={{ min: 0, step: 1 }}
                fullWidth
                sx={{ input: { color: "#fff" }, label: { color: "#ccc" } }}
              />

              <TextField
                label="Monto Kairos"
                type="number"
                value={form.kairosFinancedAmount}
                onChange={(e) =>
                  setForm((prev) => ({
                    ...prev,
                    kairosFinancedAmount: e.target.value,
                  }))
                }
                inputProps={{ min: 1, step: 1 }}
                fullWidth
                sx={{ input: { color: "#fff" }, label: { color: "#ccc" } }}
              />

              <TextField
                select
                label="Cuotas semanales Kairos"
                value={form.kairosWeeklyInstallments}
                onChange={(e) =>
                  setForm((prev) => ({
                    ...prev,
                    kairosWeeklyInstallments: e.target.value,
                  }))
                }
                fullWidth
                sx={{ input: { color: "#fff" }, label: { color: "#ccc" } }}
              >
                {[6, 8, 10, 12, 15, 18, 20, 22, 24, 26, 28, 30, 32, 34, 36].map(
                  (q) => (
                    <MenuItem key={q} value={q}>
                      {q} cuotas semanales
                    </MenuItem>
                  )
                )}
              </TextField>

              <TextField
                label="Fecha de venta"
                type="date"
                value={form.saleDate}
                onChange={(e) =>
                  setForm((prev) => ({ ...prev, saleDate: e.target.value }))
                }
                InputLabelProps={{ shrink: true }}
                fullWidth
                sx={{ input: { color: "#fff" }, label: { color: "#ccc" } }}
              />

              <TextField
                label="Primer vencimiento (+7 días)"
                type="date"
                value={kairosFirstDueDate}
                InputProps={{ readOnly: true }}
                InputLabelProps={{ shrink: true }}
                fullWidth
                sx={{ input: { color: "#fff" }, label: { color: "#ccc" } }}
              />
            </>
          )}

          {isMotoPlanPayment && (
            <TextField
              select
              label="Plan de Moto"
              value={form.selectedMotoPlan}
              onChange={(e) =>
                setForm((prev) => ({
                  ...prev,
                  selectedMotoPlan: e.target.value,
                }))
              }
              fullWidth
              sx={{ input: { color: "#fff" }, label: { color: "#ccc" } }}
            >
              {motoPlans.map((p) => (
                <MenuItem key={p.code} value={p.code}>
                  {p.name} ({p.installments} cuotas)
                </MenuItem>
              ))}
            </TextField>
          )}

          {form.paymentType === "anticipo_financiacion" && (
            <TextField
              label="Anticipo"
              type="number"
              value={form.downPayment}
              onChange={(e) =>
                setForm((prev) => ({ ...prev, downPayment: e.target.value }))
              }
              fullWidth
              sx={{ input: { color: "#fff" }, label: { color: "#ccc" } }}
            />
          )}

          {form.paymentType === "anticipo_financiacion" && (
            <TextField
              label="Monto Préstamo Prendario (neto)"
              type="number"
              value={form.montoPrendario}
              onChange={(e) =>
                setForm((prev) => ({
                  ...prev,
                  montoPrendario: e.target.value,
                }))
              }
              fullWidth
              error={!!errors.prendario}
              helperText={errors.prendario}
              sx={{ input: { color: "#fff" }, label: { color: "#ccc" } }}
            />
          )}

          {form.paymentType === "anticipo_financiacion" && (
            <TextField
              label="Monto Préstamo Personal BNA (neto)"
              type="number"
              value={form.montoPersonal}
              onChange={(e) =>
                setForm((prev) => ({
                  ...prev,
                  montoPersonal: e.target.value,
                }))
              }
              fullWidth
              sx={{ input: { color: "#fff" }, label: { color: "#ccc" } }}
            />
          )}

          {form.paymentType === "anticipo_financiacion" && (
            <TextField
              label="Crédito Interno (neto)"
              type="number"
              value={form.montoFinanciacion}
              onChange={(e) =>
                setForm((prev) => ({
                  ...prev,
                  montoFinanciacion: e.target.value,
                }))
              }
              fullWidth
              error={!!errors.financiacion}
              helperText={errors.financiacion}
              sx={{ input: { color: "#fff" }, label: { color: "#ccc" } }}
            />
          )}

          {form.paymentType === "anticipo_financiacion" && (
            <TextField
              select
              label="Cantidad de Cuotas"
              value={form.installments}
              onChange={(e) =>
                setForm((prev) => ({ ...prev, installments: e.target.value }))
              }
              error={missingInstallments}
              helperText={
                missingInstallments
                  ? "Debe seleccionar la cantidad de cuotas."
                  : " "
              }
              fullWidth
              sx={{ input: { color: "#fff" }, label: { color: "#ccc" } }}
            >
              {Array.from({ length: 48 }, (_, idx) => idx + 1).map((q) => (
                <MenuItem key={q} value={q}>
                  {q} cuotas
                </MenuItem>
              ))}
            </TextField>
          )}

          {(form.paymentType === "anticipo_financiacion" ||
            form.paymentType === "plan_motos_0km") && (
            <>
              <TextField
                select
                label="Día de pago"
                value={form.paymentDay}
                onChange={(e) =>
                  setForm((prev) => ({
                    ...prev,
                    paymentDay: Number(e.target.value),
                  }))
                }
                fullWidth
                sx={{ input: { color: "#fff" }, label: { color: "#ccc" } }}
              >
                {[5, 10, 15, 30].map((d) => (
                  <MenuItem key={d} value={d}>
                    {d}
                  </MenuItem>
                ))}
              </TextField>

              <TextField
                select
                label="Mes inicial de pago"
                value={form.initialPaymentMonth}
                onChange={(e) =>
                  setForm((prev) => ({
                    ...prev,
                    initialPaymentMonth: e.target.value,
                  }))
                }
                fullWidth
                sx={{ input: { color: "#fff" }, label: { color: "#ccc" } }}
              >
                {nextTwoMonths.map((m) => (
                  <MenuItem key={m} value={m}>
                    {m}
                  </MenuItem>
                ))}
              </TextField>
            </>
          )}
        </Box>

        {isKairosPayment && kairosFinancedAmount > 0 && (
          <Paper
            sx={{
              mt: 2,
              p: 2,
              backgroundColor: "#25253a",
              border: "1px solid rgba(255,255,255,0.08)",
            }}
          >
            <Typography variant="h6" sx={{ color: "#fff", mb: 1 }}>
              Simulación Financiación Kairos
            </Typography>
            <Typography sx={{ color: "#ddd" }}>
              Capital financiado: {formatPesos(kairosFinancedAmount)}
            </Typography>
            <Typography sx={{ color: "#ddd" }}>
              Interés aplicado: 25% mensual durante {kairosWeeklyInstallments || 0} semanas
            </Typography>
            <Typography sx={{ color: "#ddd" }}>
              Total a devolver: {formatPesos(kairosTotalToRepay)}
            </Typography>
            <Typography sx={{ color: "#ddd" }}>
              Cuotas semanales: {kairosWeeklyInstallments || "-"}
            </Typography>
            <Typography sx={{ color: "#ddd" }}>
              Valor estimado por cuota: {formatPesos(kairosInstallmentValue)}
            </Typography>
            <Typography sx={{ color: "#ddd" }}>
              Mora: 1% diario sobre el saldo vencido
            </Typography>
          </Paper>
        )}

        {isMotoPlanPayment && selectedMotoPlanConfig && (
          <Paper
            sx={{
              mt: 2,
              p: 2,
              backgroundColor: "#25253a",
              border: "1px solid rgba(255,255,255,0.08)",
            }}
          >
            <Typography variant="h6" sx={{ color: "#fff", mb: 1 }}>
              Detalle del {selectedMotoPlanConfig.name}
            </Typography>

            <Typography sx={{ color: "#ddd" }}>
              Anticipo: {formatPesos(selectedMotoPlanConfig.downPayment)}
            </Typography>

            {selectedMotoPlanConfig.firstInstallmentsCount > 0 ? (
              <>
                <Typography sx={{ color: "#ddd" }}>
                  Primeras {selectedMotoPlanConfig.firstInstallmentsCount} cuotas:{" "}
                  {formatPesos(selectedMotoPlanConfig.firstInstallmentAmount)}
                </Typography>
                <Typography sx={{ color: "#ddd" }}>
                  Siguientes {motoPlanRemainingInstallments} cuotas:{" "}
                  {formatPesos(selectedMotoPlanConfig.remainingInstallmentAmount)}
                </Typography>
              </>
            ) : (
              <Typography sx={{ color: "#ddd" }}>
                {selectedMotoPlanConfig.totalInstallments} cuotas fijas de{" "}
                {formatPesos(selectedMotoPlanConfig.remainingInstallmentAmount)}
              </Typography>
            )}

            <Typography sx={{ color: "#ddd" }}>
              Total de cuotas: {selectedMotoPlanConfig.totalInstallments}
            </Typography>

          </Paper>
        )}

        {compositionMismatch && (
          <Box mt={2}>
            <Typography color="warning.main" variant="body2">
              Los montos no suman el valor del auto. Anticipo, permuta,
              prendario y financiación deben sumar {formatPesos(vehiclePrice)}.
              Actualmente suman {formatPesos(totalComposition)}.
            </Typography>
          </Box>
        )}

        <Box mt={3} textAlign="right">
          <Button
            variant="contained"
            color="primary"
            sx={{ borderRadius: 2 }}
            onClick={() => setPreviewOpen(true)}
            disabled={
              !form.vehicleId ||
              !form.paymentType ||
              hasErrors ||
              (form.paymentType === "anticipo_financiacion" &&
                missingInstallments) ||
              (isMotoPlanPayment && !form.selectedMotoPlan) ||
              kairosDataMissing ||
              compositionMismatch
            }
          >
            Previsualizar
          </Button>
        </Box>
      </Paper>

      <Dialog
        open={previewOpen}
        onClose={() => setPreviewOpen(false)}
        maxWidth="sm"
        fullWidth
      >
        <DialogTitle>Previsualización del Comprobante de Venta</DialogTitle>
        <DialogContent>
          <Typography>Cliente: {form.clientName || "-"}</Typography>
          <Typography>
            Vehículo:{" "}
            {selectedVehicle
              ? `${selectedVehicle.brand} ${selectedVehicle.model} ${
                  selectedVehicle.versionName || ""
                }`
              : "-"}
          </Typography>
          <Typography>
            Forma de pago: {labelPayment(form.paymentType)}
          </Typography>

          {isKairosPayment && (
            <Box sx={{ mt: 2 }}>
              <Typography variant="h6" sx={{ color: "#009879", mb: 1 }}>
                Detalle Financiación Kairos
              </Typography>
              <Typography>
                Capital financiado: {formatPesos(kairosFinancedAmount)}
              </Typography>
              <Typography>Interés aplicado: 25% mensual</Typography>
              <Typography>
                Total a devolver: {formatPesos(kairosTotalToRepay)}
              </Typography>
              <Typography>
                Cuotas semanales: {kairosWeeklyInstallments || "-"}
              </Typography>
              <Typography>
                Valor estimado por cuota: {formatPesos(kairosInstallmentValue)}
              </Typography>
              <Typography>Anticipo: {formatPesos(form.downPayment)}</Typography>
              <Typography>Prendario: {formatPesos(form.montoPrendario)}</Typography>
              <Typography>Fecha de venta: {form.saleDate || "-"}</Typography>
              <Typography>Primer vencimiento: {kairosFirstDueDate || "-"}</Typography>
              <Typography>Mora: 1% diario</Typography>
            </Box>
          )}

          {isMotoPlanPayment && form.selectedMotoPlan && (
            <Typography>Plan: {form.selectedMotoPlan}</Typography>
          )}

        {isMotoPlanPayment && selectedMotoPlanConfig && (
            <Box sx={{ mt: 2 }}>
              <Typography variant="h6" sx={{ color: "#009879", mb: 1 }}>
                Detalle del plan
              </Typography>
              <Typography>
                Anticipo: {formatPesos(selectedMotoPlanConfig.downPayment)}
              </Typography>

              {selectedMotoPlanConfig.firstInstallmentsCount > 0 ? (
                <>
                  <Typography>
                    Primeras {selectedMotoPlanConfig.firstInstallmentsCount} cuotas:{" "}
                    {formatPesos(selectedMotoPlanConfig.firstInstallmentAmount)}
                  </Typography>
                  <Typography>
                    Siguientes {motoPlanRemainingInstallments} cuotas:{" "}
                    {formatPesos(selectedMotoPlanConfig.remainingInstallmentAmount)}
                  </Typography>
                </>
              ) : (
                <Typography>
                  {selectedMotoPlanConfig.totalInstallments} cuotas fijas de{" "}
                  {formatPesos(
                    selectedMotoPlanConfig.remainingInstallmentAmount
                  )}
                </Typography>
              )}

              <Typography>
                Total de cuotas: {selectedMotoPlanConfig.totalInstallments}
              </Typography>
            </Box>
          )}

          {form.paymentType === "anticipo_financiacion" &&
            form.installments && (
              <Typography>Cuotas: {form.installments}</Typography>
            )}

          {form.paymentType === "anticipo_financiacion" &&
            form.downPayment && (
              <Typography>Anticipo: {formatPesos(form.downPayment)}</Typography>
            )}

          {form.hasTradeIn && form.tradeInValue && (
            <>
              <Typography>Permuta: {formatPesos(form.tradeInValue)}</Typography>
              {form.tradeInPlate && (
                <Typography>Patente Permuta: {form.tradeInPlate}</Typography>
              )}
            </>
          )}

          {form.paymentType === "anticipo_financiacion" &&
            valorCuotaTotalConInteres > 0 && (
              <Typography>
                Valor de Cuota total (con financiación):{" "}
                {formatPesos(valorCuotaTotalConInteres)}
              </Typography>
            )}

          {form.paymentType === "anticipo_financiacion" &&
            (netoPrendario || netoPersonal || netoFinanciacion) && (
              <Box sx={{ mt: 2 }}>
                <Typography variant="h6" sx={{ color: "#009879", mb: 1 }}>
                  Detalle de Préstamos y Financiaciones
                </Typography>

                {netoPrendario > 0 && (
                  <Paper sx={{ p: 2, mb: 1, backgroundColor: "#f9f9f9" }}>
                    <Typography variant="subtitle1" sx={{ color: "#009879" }}>
                      Préstamo Prendario
                    </Typography>
                    <Typography sx={{ color: "#000" }}>
                      Monto (neto): {formatPesos(netoPrendario)}
                    </Typography>
                    <Typography sx={{ color: "#000" }}>
                      Tasa aplicada: {tasaPrendario}%
                    </Typography>
                    <Typography sx={{ color: "#000" }}>
                      Cuotas: {form.installments || "-"}
                    </Typography>
                    <Typography sx={{ color: "#000" }}>
                      Valor de cada cuota (con financiación):{" "}
                      {nCuotas > 0
                        ? formatPesos(prendarioConInteres / nCuotas)
                        : "-"}
                    </Typography>
                  </Paper>
                )}

                {netoPersonal > 0 && (
                  <Paper sx={{ p: 2, mb: 1, backgroundColor: "#f9f9f9" }}>
                    <Typography variant="subtitle1" sx={{ color: "#009879" }}>
                      Préstamo Personal
                    </Typography>
                    <Typography sx={{ color: "#000" }}>
                      Monto (neto): {formatPesos(netoPersonal)}
                    </Typography>
                    <Typography sx={{ color: "#000" }}>
                      Tasa aplicada: {tasaPersonal}%
                    </Typography>
                    <Typography sx={{ color: "#000" }}>
                      Cuotas: {form.installments || "-"}
                    </Typography>
                    <Typography sx={{ color: "#000" }}>
                      Valor de cada cuota (con financiación):{" "}
                      {nCuotas > 0
                        ? formatPesos(personalConInteres / nCuotas)
                        : "-"}
                    </Typography>
                  </Paper>
                )}

                {netoFinanciacion > 0 && (
                  <Paper sx={{ p: 2, mb: 1, backgroundColor: "#f9f9f9" }}>
                    <Typography variant="subtitle1" sx={{ color: "#009879" }}>
                      Financiación Personal
                    </Typography>
                    <Typography sx={{ color: "#000" }}>
                      Monto (neto): {formatPesos(netoFinanciacion)}
                    </Typography>
                    <Typography sx={{ color: "#000" }}>
                      Tasa aplicada: {tasaFinanciacion}%
                    </Typography>
                    <Typography sx={{ color: "#000" }}>
                      Cuotas: {form.installments || "-"}
                    </Typography>
                    <Typography sx={{ color: "#000" }}>
                      Valor de cada cuota (con financiación):{" "}
                      {nCuotas > 0
                        ? formatPesos(financiacionConInteres / nCuotas)
                        : "-"}
                    </Typography>
                  </Paper>
                )}
              </Box>
            )}

<Box textAlign="center" mt={3}>
  <LoadingActionButton
    variant="contained"
    color="primary"
    sx={{ mr: 2 }}
    onClick={handleSaveSale}
    loading={savingSale}
    loadingText="Generando..."
    disabled={
      hasErrors ||
      !form.vehicleId ||
      !form.paymentType ||
      (form.paymentType === "anticipo_financiacion" &&
        missingInstallments) ||
      (isMotoPlanPayment && !form.selectedMotoPlan) ||
      kairosDataMissing ||
      compositionMismatch
    }
  >
    Vender y Descargar PDF
  </LoadingActionButton>

  <Button
    variant="outlined"
    color="secondary"
    onClick={() => setPreviewOpen(false)}
    disabled={savingSale}
  >
    Cerrar
  </Button>
</Box>
        </DialogContent>
      </Dialog>

      <Snackbar
        open={alert.open}
        autoHideDuration={4500}
        onClose={() => setAlert({ ...alert, open: false })}
        anchorOrigin={{ vertical: "bottom", horizontal: "center" }}
      >
        <Alert
          onClose={() => setAlert({ ...alert, open: false })}
          severity={alert.severity}
          sx={{ width: "100%" }}
        >
          {alert.message}
        </Alert>
      </Snackbar>
    </Box>
  );
};

export default Sales;
