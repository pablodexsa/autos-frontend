﻿import React from "react";
import { BrowserRouter as Router, Routes, Route, useLocation } from "react-router-dom";
import { ThemeProvider, CssBaseline, Box, Toolbar } from "@mui/material";
import { SnackbarProvider } from "notistack";

// Layout & UI
import Sidebar from "./components/Sidebar";
import Header from "./components/Header";

// Auth & Providers
import { AuthProvider } from "./context/AuthContext";
import ProtectedRoute from "./components/ProtectedRoute";
import NotificationProvider from "./context/NotificationProvider";

// Pages
import Login from "./pages/Login";
import Home from "./pages/Home";
import Sales from "./pages/Sales";
import Vehicles from "./pages/Vehicles";
import Clients from "./pages/Clients";
import RolesPage from "./pages/RolesPage";
import Budgets from "./pages/Budgets";
import BudgetReports from "./pages/BudgetReports";
import UsersPage from "./pages/UsersPage";
import InstallmentPayments from "./pages/InstallmentPayments";
import Installments from "./pages/Installments";
import ReservationsPage from "./pages/ReservationsPage";
import ReservationListPage from "./pages/ReservationListPage";
import AuditPage from "./pages/AuditPage";
import SalesList from "./pages/SalesList";
import SettingsPage from "./pages/settings";
import Refunds from "./pages/Refunds";
import DirectoLeads from "./pages/DirectoLeads";
import ManagerDashboard from "./pages/ManagerDashboard";
import CuotaRedLeads from "./pages/CuotaRedLeads";
import JudicialExecutions from "./pages/JudicialExecutions";
import LoanClients from "./pages/LoanClients";
import Loans from "./pages/Loans";
import LoanInstallments from "./pages/LoanInstallments";
import LoanInstallmentPayments from "./pages/LoanInstallmentPayments";
import KairosLeadsPage from "./pages/KairosLeadsPage";


// Assets & global
import theme from "./theme";
import logo from "./assets/logo.jpeg";
import "./styles/global.css";

/** Layout principal */
const MainLayout: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const location = useLocation();
  const isLoginPage = location.pathname === "/login";

  if (isLoginPage) {
    return <>{children}</>;
  }

  return (
    <Box sx={{ display: "flex" }}>
      <Header />
      <Sidebar />
      <Box
        component="main"
        sx={{
          flexGrow: 1,
          p: 4,
          minHeight: "100vh",
          background: "linear-gradient(135deg, #0f0f1b 0%, #1b1b2f 100%)",
        }}
      >
        <Toolbar />
        <Toolbar />
        {children}
      </Box>
    </Box>
  );
};

const App = () => {
  return (
    <ThemeProvider theme={theme}>
      <CssBaseline />
      <Router>
        <AuthProvider>
          <NotificationProvider>
            <SnackbarProvider maxSnack={3} autoHideDuration={3000}>
              <MainLayout>
                <Routes>
                  {/* ✅ RUTA PÚBLICA */}
                  <Route path="/login" element={<Login />} />

                  {/* ✅ RUTAS PROTEGIDAS */}
                  <Route
                    path="/home"
                    element={
                      <ProtectedRoute permissionKey="home">
                        <Home />
                      </ProtectedRoute>
                    }
                  />

                  <Route
                    path="/roles"
                    element={
                      <ProtectedRoute roles={["admin"]} permissionKey="roles">
                        <RolesPage />
                      </ProtectedRoute>
                    }
                  />

                  <Route
                    path="/reservations"
                    element={
                      <ProtectedRoute permissionKey="reservations">
                        <ReservationsPage />
                      </ProtectedRoute>
                    }
                  />

                  <Route
                    path="/reservations/edit/:id"
                    element={
                      <ProtectedRoute permissionKey="reservations">
                        <ReservationsPage />
                      </ProtectedRoute>
                    }
                  />

                  <Route
                    path="/reservation-list"
                    element={
                      <ProtectedRoute permissionKey="reservation-list">
                        <ReservationListPage />
                      </ProtectedRoute>
                    }
                  />

                  <Route
                    path="/refunds"
                    element={
                      <ProtectedRoute permissionKey="refunds">
                        <Refunds />
                      </ProtectedRoute>
                    }
                  />

                  <Route
                    path="/sales"
                    element={
                      <ProtectedRoute permissionKey="sales">
                        <Sales />
                      </ProtectedRoute>
                    }
                  />

                  <Route
                    path="/sales/list"
                    element={
                      <ProtectedRoute permissionKey="sales-list">
                        <SalesList />
                      </ProtectedRoute>
                    }
                  />

                  <Route
                    path="/installment-payments"
                    element={
                      <ProtectedRoute permissionKey="installment-payments">
                        <InstallmentPayments />
                      </ProtectedRoute>
                    }
                  />

                  <Route
                    path="/installments"
                    element={
                      <ProtectedRoute permissionKey="installments">
                        <Installments />
                      </ProtectedRoute>
                    }
                  />

<Route
  path="/judicial-executions"
  element={
    <ProtectedRoute permissionKey="judicial-executions">
      <JudicialExecutions />
    </ProtectedRoute>
  }
/>

                  <Route
                    path="/vehicles"
                    element={
                      <ProtectedRoute permissionKey="vehicles">
                        <Vehicles />
                      </ProtectedRoute>
                    }
                  />

                  <Route
                    path="/clients"
                    element={
                      <ProtectedRoute permissionKey="clients">
                        <Clients />
                      </ProtectedRoute>
                    }
                  />

                  <Route
                    path="/budgets"
                    element={
                      <ProtectedRoute permissionKey="budgets">
                        <Budgets />
                      </ProtectedRoute>
                    }
                  />

<Route
  path="/directo"
  element={
    <ProtectedRoute permissionKey="directo">
      <DirectoLeads />
    </ProtectedRoute>
  }
/>

<Route
  path="/cuotared"
  element={
    <ProtectedRoute permissionKey="cuotared">
      <CuotaRedLeads />
    </ProtectedRoute>
  }
/>

<Route
  path="/kairos-leads"
  element={
    <ProtectedRoute permissionKey="kairos-leads">
      <KairosLeadsPage />
    </ProtectedRoute>
  }
/>

<Route
  path="/loan-clients"
  element={
    <ProtectedRoute permissionKey="loan-clients">
      <LoanClients />
    </ProtectedRoute>
  }
/>

<Route
  path="/loans"
  element={
    <ProtectedRoute permissionKey="loans">
      <Loans />
    </ProtectedRoute>
  }
/>

<Route
  path="/loan-installments"
  element={
    <ProtectedRoute permissionKey="loan-installments">
      <LoanInstallments />
    </ProtectedRoute>
  }
/>

<Route
  path="/loan-installment-payments"
  element={
    <ProtectedRoute permissionKey="loan-installment-payments">
      <LoanInstallmentPayments />
    </ProtectedRoute>
  }
/>

<Route
  path="/dashboard-gerencial"
  element={
    <ProtectedRoute permissionKey="dashboard_gerencial">
      <ManagerDashboard />
    </ProtectedRoute>
  }
/>

                  <Route
                    path="/budget-reports"
                    element={
                      <ProtectedRoute permissionKey="budget-reports">
                        <BudgetReports />
                      </ProtectedRoute>
                    }
                  />

                  <Route
                    path="/settings"
                    element={
                      <ProtectedRoute permissionKey="settings">
                        <SettingsPage />
                      </ProtectedRoute>
                    }
                  />

                  <Route
                    path="/audit"
                    element={
                      <ProtectedRoute roles={["admin"]} permissionKey="audit">
                        <AuditPage />
                      </ProtectedRoute>
                    }
                  />

                  <Route
                    path="/users"
                    element={
                      <ProtectedRoute roles={["admin"]} permissionKey="users">
                        <UsersPage />
                      </ProtectedRoute>
                    }
                  />

                  {/* ✅ PÁGINA DE INICIO */}
                  <Route
                    path="/"
                    element={
                      <ProtectedRoute permissionKey="home">
                        <Box
                          sx={{
                            display: "flex",
                            alignItems: "center",
                            justifyContent: "center",
                            height: "80vh",
                            color: "#E0E0E0",
                            flexDirection: "column",
                            textAlign: "center",
                          }}
                        >
                          <Box
                            component="img"
                            src={logo}
                            alt="GL Motors"
                            sx={{
                              width: 200,
                              mb: 3,
                              borderRadius: 2,
                              animation: "shine 3s infinite linear",
                              "@keyframes shine": {
                                "0%": { filter: "brightness(1)" },
                                "50%": { filter: "brightness(1.8)" },
                                "100%": { filter: "brightness(1)" },
                              },
                            }}
                          />

                          <h1>Bienvenido a GL Motors</h1>
                          <p>Gestione sus ventas, clientes y presupuestos fácilmente.</p>
                        </Box>
                      </ProtectedRoute>
                    }
                  />
                </Routes>
              </MainLayout>
            </SnackbarProvider>
          </NotificationProvider>
        </AuthProvider>
      </Router>
    </ThemeProvider>
  );
};

export default App;