import React from "react";
import {
  Paper,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
} from "@mui/material";

interface Purchase {
  id: number;
  amount: number | string;
  createdAt: string;
  client?: {
    firstName?: string;
    lastName?: string;
  };
  vehicle?: {
    brand?: string;
    model?: string;
    year?: number;
    plate?: string;
  };
}

export function PurchaseTable({ purchases }: { purchases: Purchase[] }) {
  return (
    <TableContainer component={Paper} sx={{ mt: 2, borderRadius: 2 }}>
      <Table>
        <TableHead>
          <TableRow>
            <TableCell>#</TableCell>
            <TableCell>Fecha</TableCell>
            <TableCell>Vehículo</TableCell>
            <TableCell>Cliente / vendedor</TableCell>
            <TableCell align="right">Precio compra</TableCell>
          </TableRow>
        </TableHead>
        <TableBody>
          {purchases.length ? (
            purchases.map((purchase) => (
              <TableRow key={purchase.id} hover>
                <TableCell>{purchase.id}</TableCell>
                <TableCell>
                  {purchase.createdAt
                    ? new Date(purchase.createdAt).toLocaleDateString("es-AR")
                    : "-"}
                </TableCell>
                <TableCell>
                  {purchase.vehicle
                    ? `${purchase.vehicle.brand ?? ""} ${purchase.vehicle.model ?? ""} ${purchase.vehicle.year ?? ""} ${purchase.vehicle.plate ? `(${purchase.vehicle.plate})` : ""}`.trim()
                    : "-"}
                </TableCell>
                <TableCell>
                  {purchase.client
                    ? `${purchase.client.firstName ?? ""} ${purchase.client.lastName ?? ""}`.trim()
                    : "-"}
                </TableCell>
                <TableCell align="right">
                  $ {Number(purchase.amount || 0).toLocaleString("es-AR")}
                </TableCell>
              </TableRow>
            ))
          ) : (
            <TableRow>
              <TableCell colSpan={5} align="center">
                No hay compras registradas aún.
              </TableCell>
            </TableRow>
          )}
        </TableBody>
      </Table>
    </TableContainer>
  );
}
