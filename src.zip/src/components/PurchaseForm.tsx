import { useEffect, useMemo, useState } from "react";
import {
  Alert,
  Box,
  Button,
  Grid,
  IconButton,
  MenuItem,
  Stack,
  TextField,
  Typography,
} from "@mui/material";
import DeleteOutlineIcon from "@mui/icons-material/DeleteOutline";
import AddIcon from "@mui/icons-material/Add";
import { api } from "../api";
import { treasuryApi } from "../api/treasury";
import type {
  TreasuryAccount,
  TreasuryPaymentMethod,
} from "../types/treasury";

type AllocationRow = {
  accountId: string;
  amount: string;
  paymentMethod: TreasuryPaymentMethod;
};

export function PurchaseForm({ onAdded }: { onAdded: () => void }) {
  const [vehicleId, setVehicleId] = useState("");
  const [clientId, setClientId] = useState("");
  const [amount, setAmount] = useState("");
  const [accounts, setAccounts] = useState<TreasuryAccount[]>([]);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");
  const [allocations, setAllocations] = useState<AllocationRow[]>([
    { accountId: "", amount: "", paymentMethod: "TRANSFER" },
  ]);

  useEffect(() => {
    treasuryApi
      .accounts("GL_MOTORS")
      .then((rows) => setAccounts(rows.filter((row) => row.isActive)))
      .catch(() => setError("No se pudieron cargar las cuentas de Tesorería GL"));
  }, []);

  const purchaseAmount = Number(amount || 0);
  const allocatedAmount = useMemo(
    () => allocations.reduce((sum, row) => sum + Number(row.amount || 0), 0),
    [allocations],
  );
  const difference = purchaseAmount - allocatedAmount;

  const updateAllocation = (
    index: number,
    patch: Partial<AllocationRow>,
  ) => {
    setAllocations((current) =>
      current.map((row, i) => (i === index ? { ...row, ...patch } : row)),
    );
  };

  const addAllocation = () =>
    setAllocations((current) => [
      ...current,
      { accountId: "", amount: "", paymentMethod: "TRANSFER" },
    ]);

  const removeAllocation = (index: number) =>
    setAllocations((current) =>
      current.length === 1 ? current : current.filter((_, i) => i !== index),
    );

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");

    if (!vehicleId || !clientId || purchaseAmount <= 0) {
      setError("Completá vehículo, cliente/vendedor y monto de compra");
      return;
    }

    if (
      allocations.some(
        (row) =>
          !row.accountId ||
          !row.amount ||
          Number(row.amount) <= 0,
      )
    ) {
      setError("Completá todas las cuentas e importes de Tesorería");
      return;
    }

    if (Math.abs(difference) > 0.01) {
      setError("La distribución entre cuentas debe coincidir con el monto total de la compra");
      return;
    }

    try {
      setSaving(true);
      await api.post("/purchases", {
        vehicleId: Number(vehicleId),
        clientId: Number(clientId),
        amount: purchaseAmount,
        treasuryAllocations: allocations.map((row) => ({
          accountId: Number(row.accountId),
          amount: Number(row.amount),
          paymentMethod: row.paymentMethod,
        })),
      });

      setVehicleId("");
      setClientId("");
      setAmount("");
      setAllocations([
        { accountId: "", amount: "", paymentMethod: "TRANSFER" },
      ]);
      onAdded();
    } catch (err: any) {
      setError(
        err?.response?.data?.message ||
          err?.response?.data?.mensaje ||
          "Error al registrar compra",
      );
    } finally {
      setSaving(false);
    }
  };

  return (
    <Box
      component="form"
      onSubmit={handleSubmit}
      sx={{
        p: 2,
        mb: 2,
        borderRadius: 2,
        backgroundColor: "#1e1e2f",
        border: "1px solid rgba(255,255,255,0.08)",
      }}
    >
      <Typography variant="h6" sx={{ mb: 2 }}>
        Registrar compra de vehículo
      </Typography>

      {error && <Alert severity="error" sx={{ mb: 2 }}>{error}</Alert>}

      <Grid container spacing={2}>
        <Grid item xs={12} md={4}>
          <TextField
            fullWidth
            label="ID Vehículo"
            value={vehicleId}
            onChange={(e) => setVehicleId(e.target.value)}
            required
          />
        </Grid>
        <Grid item xs={12} md={4}>
          <TextField
            fullWidth
            label="ID Cliente / vendedor"
            value={clientId}
            onChange={(e) => setClientId(e.target.value)}
            required
          />
        </Grid>
        <Grid item xs={12} md={4}>
          <TextField
            fullWidth
            type="number"
            label="Monto de compra"
            value={amount}
            onChange={(e) => setAmount(e.target.value)}
            required
          />
        </Grid>
      </Grid>

      <Typography variant="subtitle1" sx={{ mt: 3, mb: 1 }}>
        ¿Desde qué cuenta/s se pagó?
      </Typography>

      <Stack spacing={2}>
        {allocations.map((row, index) => (
          <Grid container spacing={2} alignItems="center" key={index}>
            <Grid item xs={12} md={4}>
              <TextField
                select
                fullWidth
                label="Cuenta GL"
                value={row.accountId}
                onChange={(e) =>
                  updateAllocation(index, { accountId: e.target.value })
                }
              >
                {accounts.map((account) => (
                  <MenuItem key={account.id} value={account.id}>
                    {account.name}
                  </MenuItem>
                ))}
              </TextField>
            </Grid>

            <Grid item xs={12} md={3}>
              <TextField
                fullWidth
                type="number"
                label="Importe"
                value={row.amount}
                onChange={(e) =>
                  updateAllocation(index, { amount: e.target.value })
                }
              />
            </Grid>

            <Grid item xs={10} md={4}>
              <TextField
                select
                fullWidth
                label="Medio de pago"
                value={row.paymentMethod}
                onChange={(e) =>
                  updateAllocation(index, {
                    paymentMethod: e.target.value as TreasuryPaymentMethod,
                  })
                }
              >
                <MenuItem value="TRANSFER">Transferencia</MenuItem>
                <MenuItem value="CASH">Efectivo</MenuItem>
                <MenuItem value="WALLET">Billetera</MenuItem>
                <MenuItem value="CHECK">Cheque</MenuItem>
                <MenuItem value="DEBIT">Débito</MenuItem>
                <MenuItem value="CREDIT">Crédito</MenuItem>
                <MenuItem value="OTHER">Otro</MenuItem>
              </TextField>
            </Grid>

            <Grid item xs={2} md={1}>
              <IconButton
                onClick={() => removeAllocation(index)}
                disabled={allocations.length === 1}
              >
                <DeleteOutlineIcon />
              </IconButton>
            </Grid>
          </Grid>
        ))}
      </Stack>

      <Stack direction="row" spacing={2} sx={{ mt: 2 }} alignItems="center">
        <Button startIcon={<AddIcon />} onClick={addAllocation}>
          Agregar cuenta
        </Button>
        <Typography variant="body2">
          Distribuido: $ {allocatedAmount.toLocaleString("es-AR")} / Total: $ {purchaseAmount.toLocaleString("es-AR")}
        </Typography>
      </Stack>

      <Button
        sx={{ mt: 2 }}
        variant="contained"
        type="submit"
        disabled={saving || Math.abs(difference) > 0.01}
      >
        {saving ? "Registrando..." : "Registrar compra"}
      </Button>
    </Box>
  );
}
